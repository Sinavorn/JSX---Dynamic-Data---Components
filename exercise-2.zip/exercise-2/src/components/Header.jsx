import React from "react";

function Header() {
  return (
    <header className="block">
      <h1> Welcome again ! </h1>
      <p></p>
    </header>
  );
}

export default Header;

function Time() {
    let time = new Date().toLocaleTimeString(); // Get only the time
    return(
        <h2>
            {time}
        </h2>
    );
}

export default Time;

